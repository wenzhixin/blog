module.exports = {
	ftp: {
		host: '192.168.88.10',
		user: 'scutech',
		password: 'dingjia'
	},
	
	install_path: 'C:\\Program Files\\Scutech\\AnBay\\localUI',
	
	debug_path: 'D:\\wenyi\\scutech\\OnlineBackup\\bin-debug'
};