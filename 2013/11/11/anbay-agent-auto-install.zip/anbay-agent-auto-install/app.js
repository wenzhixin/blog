var fs = require('fs'),
	Client = require('ftp'),
	exec = require('child_process').exec,
	config = require('./config'),
	client = new Client();
		
function getPackage(callback) {
	client.on('ready', function() {
		var year = (new Date()).getFullYear(),
			path = 'ftp_product_installer/onlinebackup/' + year + '/anbay';
		
		client.cwd(path, function(err) {
			client.list(function(err, list) {
				client.cwd(getMaxVersion(list), function(err) {
					client.list(function(err, list) {
						var name = '',
							version = 0;
							
						list.forEach(function(item) {
							var m = item.name.match(/^anbay-agent_\d+.\d+.(\d+).\d+.exe$/);
							
							if (m && version < +m[1]) {
								name = item.name;
								version = +m[1];
							}
						});
						client.get(name, function(err, stream) {
							stream.on('close', function() {
								client.end();
								callback(__dirname + '\\' + name);
							});
							stream.pipe(fs.createWriteStream(name));
						});
					});
				});
			});
		});
	});
	client.connect(config.ftp);
}

function getMaxVersion(list) {
	var max = '0.0.0',
		compare = function(a, b) {
			if (+a[0] < b[0]) return true;
			if (+a[1] < b[1]) return true;
			if (+a[2] < b[2]) return true;
			return false;
		};
		
	list.forEach(function(item) {
		if (compare(max.split('.'), item.name.split('.'))) {
			max = item.name;
		}
	});
	return max;
}

function installPackage(path, callback) {
	var cmd = path + ' /qn /norestart QUIET=1';

	exec(cmd, function(err, stdout, stderr) {
		if (err) throw err;
		exec('del ' + path, callback);
	});
}

function updateConfig() {
	var configFile = 'C:/ProgramData/scutech/AnBay/mongoose.conf',
		content = fs.readFileSync(configFile).toString();
	
	content = content.replace(config.install_path, config.debug_path);
	fs.writeFileSync(configFile, content);
	
	exec('sc stop ScutechAnBayAgent', function(err, stdout, stderr) {
		exec('sc start ScutechAnBayAgent', function(err, stdout, stderr) {
			console.log('ok');
		});
	});
}

getPackage(function(path) {
	installPackage(path, function(err) {
		updateConfig();
	});
});