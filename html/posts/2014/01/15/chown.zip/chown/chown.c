#include <windows.h>
#include <lm.h>
#include <stdio.h>
#include <string.h>

#define MAXPATHLEN 1024 // max. length of path to a file + filename
#define MAXNAMELEN 256

#define RETVAL_SUCCESS          0
#define RETVAL_INVALID_CMDLINE  1
#define RETVAL_VERSIONERR       2
#define RETVAL_PRIVSERR         3
#define RETVAL_MODIFYERR        4
#define RETVAL_FILEERR          5

#define toUnicode(FROM,TO)                     \
    MultiByteToWideChar(CP_OEMCP,              \
                        0,                     \
                        (char *)FROM,          \
                        strlen((char *)FROM)+1,\
                        TO,                    \
                        sizeof(TO))

#define fromUnicode(FROM,TO)             \
    WideCharToMultiByte(CP_OEMCP,        \
                        0,               \
                        FROM,            \
                        -1,              \
                        TO,              \
                        sizeof(TO),      \
                        NULL,            \
                        NULL)

UCHAR szDomain[MAXNAMELEN];
WCHAR wszDomain[MAXNAMELEN];

UCHAR szOwner[MAXNAMELEN];
UCHAR szPathAndFiles[MAXPATHLEN];
UCHAR szFiles[MAXPATHLEN];
UCHAR szPath[MAXPATHLEN];

UCHAR *pFileName;

int PathLen;

BOOL bRecurseSubdirs=FALSE;
#ifdef _DEBUG
BOOL bVerbose=TRUE;
#else
BOOL bVerbose=FALSE;
#endif
BOOL bQuiet=FALSE;
BOOL bSkipDirectories=FALSE;

#define SZ_SD_BUF   100

UCHAR                ucFileSDBuf[SZ_SD_BUF] = "";
PSECURITY_DESCRIPTOR psdFileSDrel = (PSECURITY_DESCRIPTOR)&ucFileSDBuf;
PSECURITY_DESCRIPTOR psdFileSDabs = NULL;
PSID                 psidOwner;

BOOL 
GetAccountSid( 
    LPTSTR SystemName, 
    LPTSTR AccountName, 
    PSID *Sid 
    ) 
{ 
    LPTSTR ReferencedDomain=NULL; 
    DWORD cbSid=128;    // initial allocation attempt 
    DWORD cchReferencedDomain=16; // initial allocation size 
    SID_NAME_USE peUse; 
    BOOL bSuccess=FALSE; // assume this function will fail 
 
    __try { 
 
    // 
    // initial memory allocations 
    // 
    *Sid = (PSID)HeapAlloc(GetProcessHeap(), 0, cbSid); 
 
    if(*Sid == NULL) __leave; 
 
    ReferencedDomain = (LPTSTR)HeapAlloc( 
                    GetProcessHeap(), 
                    0, 
                    cchReferencedDomain * sizeof(TCHAR) 
                    ); 
 
    if(ReferencedDomain == NULL) __leave; 
 
    // 
    // Obtain the SID of the specified account on the specified system. 
    // 
    while(!LookupAccountName( 
                    SystemName,         // machine to lookup account on 
                    AccountName,        // account to lookup 
                    *Sid,               // SID of interest 
                    &cbSid,             // size of SID 
                    ReferencedDomain,   // domain account was found on 
                    &cchReferencedDomain, 
                    &peUse 
                    )) { 
        if (GetLastError() == ERROR_INSUFFICIENT_BUFFER) { 
            // 
            // reallocate memory 
            // 
            *Sid = (PSID)HeapReAlloc( 
                        GetProcessHeap(), 
                        0, 
                        *Sid, 
                        cbSid 
                        ); 
            if(*Sid == NULL) __leave; 
 
            ReferencedDomain = (LPTSTR)HeapReAlloc( 
                        GetProcessHeap(), 
                        0, 
                        ReferencedDomain, 
                        cchReferencedDomain * sizeof(TCHAR) 
                        ); 
            if(ReferencedDomain == NULL) __leave; 
        } 
        else __leave; 
    } 
 
    // 
    // Indicate success. 
    // 
    bSuccess = TRUE; 
 
    } // try 
    __finally { 
 
    // 
    // Cleanup and indicate failure, if appropriate. 
    // 
 
    HeapFree(GetProcessHeap(), 0, ReferencedDomain); 
 
    if(!bSuccess) { 
        if(*Sid != NULL) { 
            HeapFree(GetProcessHeap(), 0, *Sid); 
            *Sid = NULL; 
        } 
    } 
 
    } // finally 
 
    return bSuccess; 
} 

BOOL 
GetSid( 
    LPTSTR AccountName, 
    PSID *Sid 
    ) 
{
    PBYTE wszDomainController;
    UCHAR szDomainController[MAXNAMELEN];

    if (strlen(szDomain)>0) {
        toUnicode(szDomain,wszDomain);
        if (NetGetDCName(NULL,wszDomain,&wszDomainController)!=NERR_Success) return FALSE;
        fromUnicode((LPWSTR)wszDomainController,szDomainController);
        return GetAccountSid(szDomainController,
                             AccountName,
                             Sid);
    } else {
        return GetAccountSid(NULL,
                             AccountName,
                             Sid);
    }
}

BOOL SetPrivilege(
	HANDLE hToken,          // token handle (NULL: current process)
    LPCTSTR Privilege,      // Privilege to enable/disable
    BOOL bEnablePrivilege   // TRUE to enable.  FALSE to disable
    )
{
    TOKEN_PRIVILEGES tp;
    LUID luid;
    TOKEN_PRIVILEGES tpPrevious;
    DWORD cbPrevious=sizeof(TOKEN_PRIVILEGES);
    BOOL CloseAtEnd=FALSE;

    //
    // Retrieve a handle of the access token
    //
    if (hToken==NULL) {
		if (!OpenProcessToken(GetCurrentProcess(),
				TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
				&hToken)) {
			if (bVerbose) printf("OpenProcessToken in SetPrivilege failed.\n");
			return FALSE;
		}
        CloseAtEnd=TRUE;
	}

    if (!LookupPrivilegeValue( NULL, Privilege, &luid )) {
		if (bVerbose) printf("LookupPrivilegeValue in SetPrivilege failed.\n");
		return FALSE;
	}

    //
    // first pass.  get current privilege setting
    //
    tp.PrivilegeCount           = 1;
    tp.Privileges[0].Luid       = luid;
    tp.Privileges[0].Attributes = 0;

    AdjustTokenPrivileges(
            hToken,
            FALSE,
            &tp,
            sizeof(TOKEN_PRIVILEGES),
            &tpPrevious,
            &cbPrevious
            );

    if (GetLastError() != ERROR_SUCCESS) {
		if (bVerbose) printf("AdjustTokenPrivileges in SetPrivilege failed.\n");
		return FALSE;
	}

    //
    // second pass.  set privilege based on previous setting
    //
    tpPrevious.PrivilegeCount       = 1;
    tpPrevious.Privileges[0].Luid   = luid;

    if(bEnablePrivilege) {
        tpPrevious.Privileges[0].Attributes |= (SE_PRIVILEGE_ENABLED);
    }
    else {
        tpPrevious.Privileges[0].Attributes ^= (SE_PRIVILEGE_ENABLED &
            tpPrevious.Privileges[0].Attributes);
    }

    AdjustTokenPrivileges(
            hToken,
            FALSE,
            &tpPrevious,
            cbPrevious,
            NULL,
            NULL
            );

    if (GetLastError() != ERROR_SUCCESS) {
		if (bVerbose) printf("AdjustTokenPrivileges in SetPrivilege failed.\n");
		return FALSE;
	}

    /* call CloseHandle or not ??? */
    if (CloseAtEnd) {
        CloseHandle(hToken);
    }
    
    return TRUE;
}

 
void Usage(char *cmdname)
{
    printf("Usage: %s [-r] [-q] [-v] [-s] [-d domain] owner files\n",cmdname);
    printf("       change the owner of selected files, Version 1.1\n"
           "       -r (recursive)  recurse subdirectories\n"
           "       -q (quiet)      no output except fatal errors\n"
#ifdef _DEBUG
           "       -v (verbose)    print no information about actions\n"
#else
           "       -v (verbose)    print information about actions\n"
#endif
           "       -s (skip)       skip directories\n"
           "       -d (domain)     domain or machine the new owner belongs to\n"
           "       owner           new owner of files\n"
           "       files           files to be modified (may contain wildcards * and ?)\n"
           "                       owner and files must be at the end of the command line\n\n"

           "       Copyright (C) 1998 by Alexander Frink (Alexander.Frink@Uni-Mainz.DE)\n\n"

           "       This program is free software; you can redistribute it and/or modify\n"
           "       it under the terms of the GNU General Public License as published by\n"
           "       the Free Software Foundation; either version 2 of the License, or\n"
           "       (at your option) any later version.\n\n"

           "       This program is distributed in the hope that it will be useful,\n"
           "       but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
           "       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
           "       GNU General Public License for more details.\n");
    exit(RETVAL_INVALID_CMDLINE);
}

void ProcessCmdLine(int argc, char *argv[])
{
    char c, *p, *arg0;

    // algorithm for command line processing taken from SDK sample 
    // Win32/WinNT/Floppy/MFMT.C

    arg0=argv[0];

    // must have at least 3 arguments: exename, owner, files
    if (argc<3) Usage(arg0);
    strcpy(szPathAndFiles,argv[--argc]); // last arg: files
    strcpy(szOwner,argv[--argc]);        // next to last arg: owner
    szDomain[0]=0;

    if ( argc > 1 ) { 
        // other args: options
        while (--argc > 0 ) { 
            p = *++argv; 
            if (*p == '/' || *p == '-') { 
                while (c = *++p) {
                    switch (tolower(c)) { 
                    case '?': 
                        Usage(arg0);
                        break; 
                    case 'r': 
                        bRecurseSubdirs = TRUE; 
                        break; 
                    case 'v': 
#ifdef _DEBUG
                        bVerbose = FALSE;
#else
                        bVerbose = TRUE;
#endif
                        break;
                    case 'q': 
                        bQuiet = TRUE;
                        break;
                    case 's': 
                        bSkipDirectories = TRUE;
                        break;
                    case 'd': 
                        if (argc<2) Usage(arg0);
                        argc--, argv++; 
                        strcpy(szDomain,*argv); 
                        break;
                    default: 
                        Usage(arg0); 
                        break; 
                    } 
                } 
            }
        } 
    } 
    if (bQuiet) bVerbose=FALSE;
}

BOOL TestWinVersion(void)
{
    if (GetVersion() & 0x80000000) { 
        printf("Error: This program cannot run on Windows 3.x or Windows 95.\n");
        return FALSE; 
    }
    return TRUE;
}

LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize )
{
    DWORD dwRet;
    LPTSTR lpszTemp = NULL;

    dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                           NULL,
                           GetLastError(),
                           LANG_NEUTRAL,
                           (LPTSTR)&lpszTemp,
                           0,
                           NULL );

    // supplied buffer is not long enough
    if ( !dwRet || ( (long)dwSize < (long)dwRet+14 ) )
        lpszBuf[0] = TEXT('\0');
    else
    {
        lpszTemp[lstrlen(lpszTemp)-2] = TEXT('\0');  //remove cr and newline character
        sprintf( lpszBuf, TEXT("%s (0x%x)"), lpszTemp, GetLastError() );
    }

    if ( lpszTemp )
        LocalFree((HLOCAL) lpszTemp );

    return lpszBuf;
}

void PrintLastError(void)
{
    char szBuf[256];
    GetLastErrorText(szBuf,sizeof(szBuf));
    printf("Error text: %s\n",szBuf);
}


BOOL ModifyFiles(UCHAR *szPath, UCHAR *szFiles)
{
    HANDLE hFiles;
    WIN32_FIND_DATA FindData;
    UCHAR szFullPath[MAXPATHLEN];
    UCHAR szCurrentFile[MAXPATHLEN];

    if (bVerbose) printf("Modifying files and directories in %s that match pattern %s.\n",szPath,szFiles);
    strcpy(szFullPath,szPath);
    strcat(szFullPath,szFiles);
    hFiles=FindFirstFile(szFullPath,&FindData);
    if (hFiles==INVALID_HANDLE_VALUE) {
        if (GetLastError()==2) {
            if (bRecurseSubdirs) {
                if (bVerbose) printf("No matching files in this directory.\n");
                return TRUE;
            } else {
                if (!bQuiet) printf("No matching files found.\n");
            }
        } else {
            printf("Error: FindFirstFile for %s, code %i.\n",szFullPath,GetLastError());
        }
        return FALSE;
    }
    do {
        strcpy(szCurrentFile,szPath);
        strcat(szCurrentFile,FindData.cFileName);
        if (bVerbose) printf("Processing %s ... ",szCurrentFile);
        if (strcmp(FindData.cFileName,"..")==0) {
            if (bVerbose) printf("always skipping '..' directory.\n");
        } else {
            if ((FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)&&bSkipDirectories) {
                if (bVerbose) printf("skipping directory.\n");
            } else {
                if (!InitializeSecurityDescriptor(psdFileSDrel,
                                                  SECURITY_DESCRIPTOR_REVISION)) {
                    printf("Error: InitializeSecurityDescriptor, code %i.\n",GetLastError());
                    PrintLastError();
                    return FALSE;
                }
                if (!SetSecurityDescriptorOwner(psdFileSDrel,
                                                psidOwner,
                                                FALSE)) {
                    printf("Error: SetSecurityDescriptorOwner for %s, code %i.\n",szCurrentFile,GetLastError());
                    PrintLastError();
                    return FALSE;
                }
                if (!IsValidSecurityDescriptor(psdFileSDrel)) {
                    printf("Invalid SD.\n");
                    return FALSE;
                }
                if (!SetFileSecurity(szCurrentFile,
                                     (SECURITY_INFORMATION)(OWNER_SECURITY_INFORMATION),
                                     psdFileSDrel)) {
                    printf("Error: SetFileSecurity for %s, code %i.\n",szCurrentFile,GetLastError());
                    PrintLastError();
                    return FALSE;
                }
                if (bVerbose) printf("Owner set.\n");
                if ((!bQuiet)&&(!bVerbose)) printf("Changed %s\n",szCurrentFile);
            }
        }
    } while (FindNextFile(hFiles,&FindData));
    if (GetLastError()!=ERROR_NO_MORE_FILES) {
        printf("Error: FindNextFile, code %i.\n",GetLastError());
        PrintLastError();
        return FALSE;
    }
    FindClose(hFiles);
    return TRUE;
}

BOOL RecurseDirectories(UCHAR *szPath, UCHAR *szFiles)
{
    HANDLE hFiles;
    WIN32_FIND_DATA FindData;
    UCHAR szFullPath[MAXPATHLEN];
    UCHAR szCurrentDir[MAXPATHLEN];

    ModifyFiles(szPath,szFiles);
    if (bVerbose) printf("Scanning directory %s for subdirs.\n",szPath);
    strcpy(szFullPath,szPath);
    strcat(szFullPath,"*");
    hFiles=FindFirstFileEx(szFullPath,
                           FindExInfoStandard,
                           &FindData,
                           FindExSearchLimitToDirectories,
                           NULL,
                           0);
    if (hFiles==INVALID_HANDLE_VALUE) {
        if (GetLastError()==2) {
            if (bVerbose) printf("No subdirectories found in %s.\n",szPath);
            return TRUE;
        } 
        printf("Error: FindFirstFile for %s, code %i.\n",szFullPath,GetLastError());
        PrintLastError();
        return FALSE;
    }
    do {
        strcpy(szCurrentDir,szPath);
        strcat(szCurrentDir,FindData.cFileName);
        if (strcmp(FindData.cFileName,"..")==0) {
            if (bVerbose) printf("skipping '..' directory.\n");
        } else if (strcmp(FindData.cFileName,".")==0) {
            if (bVerbose) printf("skipping '.' directory.\n");
        } else if (FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (bVerbose) printf("Going to directory %s.\n",szCurrentDir);
            if (szCurrentDir[strlen(szCurrentDir)-1]!='\\') strcat(szCurrentDir,"\\");
            RecurseDirectories(szCurrentDir,szFiles);
        }
    } while (FindNextFile(hFiles,&FindData));
    if (GetLastError()!=ERROR_NO_MORE_FILES) {
        printf("Error: FindNextFile, code %i.\n",GetLastError());
        PrintLastError();
        return FALSE;
    }
    if (bVerbose) printf("Scanning of directory %s completed.\n",szPath);
    FindClose(hFiles);
    return TRUE;
}

int main(int argc, char *argv[])
{
    if (!TestWinVersion()) return RETVAL_VERSIONERR;

    ProcessCmdLine(argc, argv);

    // remove trailing backslash(es)
    while (szPathAndFiles[strlen(szPathAndFiles)-1]=='\\') {
        szPathAndFiles[strlen(szPathAndFiles)-1]=0;
    }

    if (GetFullPathName(szPathAndFiles,
                        sizeof(szPath),
                        szPath,
                        &pFileName)==0) {
        printf("Error: GetFullPathName.\n");
        return RETVAL_FILEERR;
    }
    if (pFileName!=NULL) {
        strcpy(szFiles,pFileName);
    } else {
        szFiles[0]=0;
    }
    szPath[strlen(szPath)-strlen(szFiles)]=0;
    PathLen=strlen(szPath);
    if (bVerbose) printf("path: %s, files: %s\n",szPath,szFiles);
    
    if (bVerbose) printf("Enabling privileges...");
    if (!SetPrivilege(NULL,SE_TAKE_OWNERSHIP_NAME,TRUE)) { // needed if you don't have full control
        if (!bQuiet) printf("Could not enable Take Ownership privilege, trying without.\n");
    }
    if (!SetPrivilege(NULL,SE_RESTORE_NAME,TRUE)) {
        if (!bQuiet) printf("Could not enable Restore Files privilege, trying without.\n");
    }
    if (!SetPrivilege(NULL,SE_BACKUP_NAME,TRUE)) {
        if (!bQuiet) printf("Could not enable Backup Files privilege, trying without.\n");
    }
    if (!SetPrivilege(NULL,SE_CHANGE_NOTIFY_NAME,TRUE)) {
        if (!bQuiet) printf("Could not enable Bypass Traverse Checking privilege, trying without.\n");
    }
    if (bVerbose) printf("ok.\n");
    
    if (!SetCurrentDirectory(szPath)) {
        if (bVerbose) printf("Warning: SetCurrentDirectory failed.\n");
    }
    
    if (bVerbose) printf("Getting account SID...");
    if (!GetSid(szOwner,&psidOwner)) {
        if (strlen(szDomain)>0) {
            printf("Unknown user %s from domain %s.\n",szOwner,szDomain);
        } else {
            printf("Unknown local user %s.\n",szOwner);
        }
        return FALSE;
    }
    if (bVerbose) printf("ok.\n");

    if (bRecurseSubdirs) {
        if (!RecurseDirectories(szPath,szFiles)) return RETVAL_MODIFYERR;
    } else {
        if (!ModifyFiles(szPath,szFiles)) return RETVAL_MODIFYERR;
    }

    if (!bQuiet) printf("Done.\n");
    return RETVAL_SUCCESS;
}
