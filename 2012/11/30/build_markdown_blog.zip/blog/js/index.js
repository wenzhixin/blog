/**
 * @author zhixin wen <wenzhixin2010@gmail.com>
 * @date 2012-11-29
 */

$(function() {
	'use strict';
	
	function getPost(url) {
		if (!url) {
			getPost('index');
			return;
		}
		$.ajax({
			url: 'posts/' + url + '.md', 
			success: function(data) {
				$('#post').html(markdown.toHTML(data));
			},
			error: function(data) {
				getPost('index');
			}
		});
	}
	
	getPost(url('?'));
});